# InformarCIOTeVPO

Aplicação Windows Forms para edição e gerenciamento de informações de CIOT e Vale Pedágio em arquivos MDFe (Manifesto Eletrônico de Documentos Fiscais).

## Descrição

InformarCIOTeVPO é uma ferramenta que permite carregar, editar e validar dados de:

- **MDFe** (Manifesto Eletrônico de Documentos Fiscais)
- **CIOT** (Conhecimento de Transporte Interestadual Oneroso)
- **Vale Pedágio** (informações de ANTT)
- **Dispositivos** (fornecedores de vale pedágio)

A aplicação oferece uma interface gráfica intuitiva para manipulação de arquivos XML de forma prática e segura.

## Funcionalidades

- Carregamento de arquivos XML via diálogo ou drag-and-drop
- Edição visual de dados de MDFe, CIOT e Vale Pedágio
- Validação automática de informações
- Navegação entre múltiplos dispositivos (fornecedores)
- Atalhos de teclado para operações comuns
- Detecção de alterações não salvas
- Salvamento em formato XML validado

## Tecnologias

- **.NET 8**
- **C# 12.0**
- **Windows Forms**
- **XML/XDocument** para processamento de documentos fiscais
- **High DPI Support** para monitores de alta resolução

## Estrutura do Projeto

```
InformarCIOTeVPO/
├── Formulario.cs           # Interface gráfica principal
├── Formulario.resx         # Recursos do formulário
├── Program.cs              # Ponto de entrada da aplicação
├── ConfiguracaoAplicacao.cs # Configurações iniciais
├── Models/
│   ├── MDFe.cs             # Modelo de Manifesto Eletrônico
│   ├── InfANTT.cs          # Informações de ANTT
│   ├── InfCIOT.cs          # Dados de CIOT
│   ├── ValePed.cs          # Informações de Vale Pedágio
│   └── Disp.cs             # Dados de Dispositivos
└── Properties/
	└── AssemblyInfo.cs     # Informações do assembly
```

## Como Usar

1. Abra a aplicação
2. Carregue um arquivo XML de MDFe (File > Abrir ou arraste o arquivo)
3. Edite os dados necessários nos campos da interface
4. Navegue entre dispositivos usando os botões de navegação
5. Salve as alterações (Ctrl+S ou File > Salvar)

## Requisitos

- Windows 7 ou superior
- .NET 8 Runtime

## Compilação

```powershell
# Compilar a solução
dotnet build

# Publicar a aplicação
dotnet publish -c Release
```

## Autores

Desenvolvido como ferramenta de gerenciamento de documentos fiscais eletrônicos.

## Licença

Propriedades intelectuais reservadas.
